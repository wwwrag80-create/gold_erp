# -*- coding: utf-8 -*-
"""نقطة تشغيل نظام محاسبة مصنع الذهب — عيار 18."""
import sys


def main():
    try:
        from PyQt5 import QtWidgets
    except ImportError:
        print("يلزم تثبيت PyQt5 أولاً:  pip install PyQt5")
        return
    from database.database import run_migrations_files, create_tables, db, migrate_schema
    from database.seed import (ensure_new_accounts, ensure_system_tags,
                              seed_initial_data)
    from models.entities import (ensure_employee_accrual_accounts,
                             ensure_internal_counterparties)
    create_tables()
    # استرداد تلقائي: إن كانت القاعدة مفقودة تُسحب أحدث نسخة
    try:
        from services import storage
        rec = storage.auto_recover()
        if rec.get("recovered"):
            print(f"[recovery] استُعيدت البيانات من {rec['from']}")
    except Exception:
        pass
    migrate_schema()
    run_migrations_files()
    seed_initial_data()
    ensure_new_accounts()
    with db() as conn:
        ensure_internal_counterparties(conn)
        ensure_employee_accrual_accounts(conn)
        ensure_system_tags(conn)

    from ui import styles
    from ui.login_window import LoginDialog
    from ui.main_window import MainWindow

    app = QtWidgets.QApplication(sys.argv)
    # تناسب تلقائي مع حجم شاشة المستخدم: الخطوط والحشو تصغر على
    # الأجهزة الصغيرة وتكبر على الكبيرة — فيبدو النظام متناسقاً
    # على أي جهاز بلا ضبط يدوي.
    # أيقونة البرنامج: التطبيق وشريط المهام معاً
    try:
        from services import app_icon
        app_icon.apply(app)
    except Exception:
        pass

    try:
        from ui.widgets.table_fit import apply_screen_scale
        apply_screen_scale(app)
    except Exception:
        pass
    styles.apply(app)
    dlg = LoginDialog()
    if dlg.exec_() != QtWidgets.QDialog.Accepted:
        return
    win = MainWindow(dlg.user)
    win.showMaximized()
    sys.exit(app.exec_())


# عامل المزامنة الخلفي: يبدأ صامتاً ولا يعطّل الواجهة إطلاقاً
try:
    from services import cloud_sync, licensing, tenant
    tenant.ensure_tenant_id()
    cloud_sync.start_worker()
    licensing.start_backup_worker()      # نسخ احتياطي محلي دوري
    from services import storage
    storage.start_backup_worker()        # نسخ لقرص D كل 30 دقيقة
    from services import health, preload
    health.start_health_worker()         # مراقب سلامة القيود
    # تحميل مسبق للوحدات الثقيلة (وحدة الطباعة أثقلها): تُحمَّل في
    # الخلفية بعد الإقلاع فتكون جاهزة عند أول استعمال، ولا يتجمّد
    # النظام عند أول فتح لمربع «تم الترحيل».
    preload.start(delay=2.0)
    from services import cloud_backup
    cloud_backup.start_worker()          # نسخة سحابية كل ساعة
except Exception:
    pass


if __name__ == "__main__":
    main()
