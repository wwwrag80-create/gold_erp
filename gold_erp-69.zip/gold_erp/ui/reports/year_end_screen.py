# -*- coding: utf-8 -*-
"""أداة الإقفال السنوي (Year-End Closing).

تعاين نتيجة السنة ثم تُقفلها آلياً: تصفير حسابات الإيرادات والمصروفات،
وترحيل صافي الربح/الخسارة إلى الأرباح المحتجزة أو جاري الشركاء، مع
خيار إنشاء قيد تدوير صريح للسنة الجديدة.
"""
from PyQt5 import QtCore, QtWidgets

from database.database import db
from models import closing
from ui.widgets.common import (ask, big_label, err, fill, info, make_table,
                               title_label)

COLS = ["الكود", "الحساب", "النوع", "الرصيد النقدي", "رصيد الذهب"]


class YearEndScreen(QtWidgets.QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.preview = None

        self.year = QtWidgets.QSpinBox()
        self.year.setRange(2000, 2100)
        self.year.setValue(QtCore.QDate.currentDate().year())
        btn_prev = QtWidgets.QPushButton("معاينة نتيجة السنة")
        btn_prev.clicked.connect(self.load_preview)

        self.to_partners = QtWidgets.QCheckBox(
            "ترحيل الصافي إلى جاري الشركاء بدل الأرباح المحتجزة")
        self.roll = QtWidgets.QCheckBox(
            "إنشاء قيد تدوير صريح للسنة الجديدة (اختياري)")

        btn_run = QtWidgets.QPushButton("🔒 تنفيذ الإقفال السنوي")
        btn_run.setObjectName("closeBtn")
        btn_run.clicked.connect(self.run_closing)

        head = QtWidgets.QHBoxLayout()
        head.addWidget(QtWidgets.QLabel("السنة المالية:"))
        head.addWidget(self.year)
        head.addWidget(btn_prev)
        head.addStretch(1)
        head.addWidget(btn_run)

        self.summary = big_label()
        self.table = make_table()

        lay = QtWidgets.QVBoxLayout(self)
        lay.addWidget(title_label("الإقفال السنوي — إغلاق الفترة المالية"))
        note = QtWidgets.QLabel(
            "يصفّر حسابات الإيرادات والمصروفات بقيد إقفال بتاريخ 31-12، "
            "ويرحّل صافي النتيجة إلى حقوق الملكية. أرصدة الميزانية تنتقل "
            "للسنة الجديدة تلقائياً بحكم استمرارية دفتر الأستاذ، وقيد "
            "التدوير الصريح اختياري لمن يريد فصلاً دفترياً بين السنتين.")
        note.setObjectName("cardSub")
        note.setWordWrap(True)
        lay.addWidget(note)
        lay.addLayout(head)
        lay.addWidget(self.to_partners)
        lay.addWidget(self.roll)
        lay.addWidget(self.summary)
        lay.addWidget(self.table, 1)

    def load_preview(self):
        try:
            with db() as conn:
                self.preview = closing.year_end_preview(
                    conn, int(self.year.value()))
            p = self.preview
            data = [(i["code"], i["name"],
                     "إيراد" if i["type"] == "revenue" else "مصروف",
                     f"{i['cash']:,.2f}", f"{i['gold']:,.2f}")
                    for i in p["items"]]
            fill(self.table, COLS, data)
            kind = "ربح" if p["net_cash"] >= 0 else "خسارة"
            self.summary.setText(
                f"سنة {p['year']}: {len(p['items'])} حساب نتيجة   |   "
                f"صافي ال{kind}: {p['net_cash']:,.2f} ريال · "
                f"{p['net_gold']:,.2f} جم 18")
        except Exception as e:
            err(self, e)

    def run_closing(self):
        try:
            year = int(self.year.value())
            if self.preview is None or self.preview["year"] != year:
                self.load_preview()
            if not self.preview or not self.preview["items"]:
                raise ValueError(f"لا توجد حركات إيراد أو مصروف في سنة {year}")
            target = ("جاري الشركاء" if self.to_partners.isChecked()
                      else "الأرباح المحتجزة")
            if not ask(self,
                       f"سيتم إقفال سنة {year} نهائياً:\n"
                       f"• تصفير {len(self.preview['items'])} حساب نتيجة\n"
                       f"• ترحيل صافي "
                       f"{self.preview['net_cash']:,.2f} ريال و"
                       f"{self.preview['net_gold']:,.2f} جم إلى {target}\n\n"
                       f"هل تريد المتابعة؟"):
                return
            with db() as conn:
                res = closing.run_year_end_closing(
                    conn, year, self.user["username"],
                    to_partners=self.to_partners.isChecked(),
                    open_next_year=self.roll.isChecked())
            msg = (f"تم إقفال سنة {res['year']}.\n"
                   f"قيد الإقفال: #{res['close_entry']}\n"
                   f"الحسابات المُقفلة: {res['closed_accounts']}\n"
                   f"صافي النتيجة: {res['net_cash']:,.2f} ريال · "
                   f"{res['net_gold']:,.2f} جم → {target}")
            if res["opening_entry"]:
                msg += f"\nقيد افتتاحي لسنة {year + 1}: #{res['opening_entry']}"
            info(self, msg)
            self.preview = None
            self.table.setRowCount(0)
            self.summary.setText("")
        except Exception as e:
            err(self, e)

    def refresh(self):
        pass
